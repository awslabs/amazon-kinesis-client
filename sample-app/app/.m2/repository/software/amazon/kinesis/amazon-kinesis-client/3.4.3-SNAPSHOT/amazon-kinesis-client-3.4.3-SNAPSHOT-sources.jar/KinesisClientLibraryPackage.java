package software.amazon.kinesis.common;

public final class KinesisClientLibraryPackage {
    public static final String VERSION = "3.4.3-SNAPSHOT";
}
